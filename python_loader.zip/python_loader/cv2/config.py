BINARIES_PATHS = [
    'D:/OpenCV_build/bin'
] + BINARIES_PATHS
